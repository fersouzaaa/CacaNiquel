package sp.senai.br.cacaniquel;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import java.sql.SQLOutput;

public class MainActivity extends AppCompatActivity {
    TextView tvSaldo, tvPartidas,tvPremio, tvAposta ;
    ImageView iv1, iv2, iv3;
    Button btnMais, btnMenos, btnCredito;
    ImageButton btnGirar;
    Switch swMusica;
    MediaPlayer mpSS, mpRoleta;
    AnimationDrawable adCaca1, adCaca2, adCaca3;
    int iSaldo=50,iPartidas, iPremio, iAposta=0;
    int iImagemSort1, iImagemSort2,iImagemSort3;
    AlertDialog alerta;
    int iValores[] = {2,4,6,8,12};
    int iImgs [] = {R.drawable.bota, R.drawable.ima, R.drawable.jet, R.drawable.estrela, R.drawable.caixa};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvAposta = findViewById(R.id.tvAposta);
        tvSaldo = findViewById(R.id.tvSaldo);
        tvPartidas = findViewById(R.id.tvPartidas);
        tvPremio = findViewById(R.id.tvPremio);
        iv1 = findViewById(R.id.iv1);
        iv2 = findViewById(R.id.iv2);
        iv3 = findViewById(R.id.iv3);
        btnMais = findViewById(R.id.btnMaisAposta);
        btnMenos = findViewById(R.id.btnMenosAposta);
        btnGirar = findViewById(R.id.btnGirar);
        btnCredito = findViewById(R.id.btnCredito);
        swMusica = findViewById(R.id.swMusica);
        mpSS = MediaPlayer.create(this,R.raw.ss);
        mpSS.setLooping(true);
        mpSS.setVolume(1.0f,1.0f);
        mpRoleta = MediaPlayer.create(this,R.raw.roleta);
        mpRoleta.setVolume(1.0f,1.0f);
        mpSS.start();
        tvSaldo.setText("$"+iSaldo+",00");
        iv1.setImageResource(0);
        iv2.setImageResource(0);
        iv3.setImageResource(0);
        iv1.setBackgroundResource(R.drawable.roleta);
        adCaca1 = (AnimationDrawable) iv1.getBackground();
        iv2.setBackgroundResource(R.drawable.roleta);
        adCaca2 = (AnimationDrawable) iv2.getBackground();
        iv3.setBackgroundResource(R.drawable.roleta);
        adCaca3= (AnimationDrawable) iv3.getBackground();
        //btnGirar.setEnabled(false);
    }
    public void desligar(View l) {
        if (swMusica.isChecked()) {
            mpSS.start();
        } else {
            mpSS.pause();
        }
    }
    public void mais (View ma){
        if (iSaldo<=0){
            desabilitar();
            btnCredito.setEnabled(true);
        }if(iAposta<iSaldo){
            iAposta+=10;
            //btnGirar.setEnabled(true);
        }else if (iAposta>=iSaldo) {
            iAposta=iSaldo;
        }
        tvAposta.setText("$"+iAposta+",00");
    }
    public void menos (View me){
        if (iSaldo<=0){
            desabilitar();
            btnCredito.setEnabled(true);
        }
        //btnGirar.setEnabled(true);
        if(iAposta<=iSaldo && iAposta>10){
            iAposta-=10;
        }else{
            iAposta=0;
        }
        tvAposta.setText("$"+iAposta+",00");
    }
    public void desabilitar(){
        btnMais.setEnabled(false);
        btnMenos.setEnabled(false);
        btnGirar.setEnabled(false);
    }
    public void habilitar(){
        btnMais.setEnabled(true);
        btnMenos.setEnabled(true);
        btnGirar.setEnabled(true);
    }
    public void girar(View g){
        if(iAposta>=10) {
            desabilitar();
            tvPremio.setText("$0,00");
            iv1.setImageResource(0);
            iv2.setImageResource(0);
            iv3.setImageResource(0);
            iv1.setBackgroundResource(R.drawable.roleta);
            adCaca1 = (AnimationDrawable) iv1.getBackground();
            iv2.setBackgroundResource(R.drawable.roleta);
            adCaca2 = (AnimationDrawable) iv2.getBackground();
            iv3.setBackgroundResource(R.drawable.roleta);
            adCaca3 = (AnimationDrawable) iv3.getBackground();
            adCaca1.start();
            adCaca2.start();
            adCaca3.start();
            iImagemSort1 = (int) (Math.random() * 5);
            iImagemSort2 = (int) (Math.random() * 5);
            iImagemSort3 = (int) (Math.random() * 5);
            mpRoleta.start();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(2000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                adCaca1.stop(); //Para animação
                                iv1.setBackgroundResource(iImgs[iImagemSort1]); //Muda a imagem
                            }
                        });
                    } catch (Exception e) {
                        System.out.println("ERRO: " + e);
                    }
                }
            }).start();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(3000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                adCaca2.stop(); //Para animação
                                iv2.setBackgroundResource(iImgs[iImagemSort2]); //Muda a imagem
                            }
                        });
                    } catch (Exception e) {
                        System.out.println("ERRO: " + e);
                    }
                }
            }).start();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(4000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                adCaca3.stop(); //Para animação
                                iv3.setBackgroundResource(iImgs[iImagemSort3]); //Muda a imagem
                                mpRoleta.pause(); // pausa o som
                            }
                        });
                    } catch (Exception e) {
                        System.out.println("ERRO: " + e);
                    }
                }
            }).start();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(4050);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                testar(iImagemSort1, iImagemSort2, iImagemSort3);
                                iAposta = 0;
                                tvAposta.setText("$" + iAposta + ",00");
                                iSaldo+=iPremio;
                                tvSaldo.setText("$" + iSaldo + ",00");
                                habilitar();
                            }
                        });
                    } catch (Exception e) {
                        System.out.println("ERRO: " + e);
                    }
                }
            }).start();
            iPartidas += 1;
            tvPartidas.setText(String.valueOf(iPartidas));
            iSaldo -= iAposta;
            tvSaldo.setText("$" + iSaldo + ",00");
        }else{
            AlertDialog.Builder Alerta = new AlertDialog.Builder(this);
            Alerta.setTitle("APOSTA INVÁLIDA");
            Alerta.setMessage("A aposta mínima é de $10,00");
            alerta = Alerta.create();
            alerta.show();
        }
    }
    public void testar(int iv1, int iv2, int iv3){
        if (iv1==iv2 && iv2==iv3){
            iPremio= iAposta*iValores[iv1];
            tvPremio.setText("$"+iPremio+",00");
        }else{
            tvPremio.setText("$0,00");
        }
    }
    public void credito (View c){
        iSaldo=50;
        tvSaldo.setText("$"+iSaldo+",00");
        btnCredito.setEnabled(false);
        habilitar();
    }
}