package sp.senai.br.cacaniquel;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import java.sql.SQLOutput;

public class MainActivity extends AppCompatActivity {
TextView tvAcumulado, tvSaldo, tvPartidas,tvPremio, tvAposta ;
ImageView iv1, iv2, iv3;
Button btnMais, btnMenos, btnCredito, btnGirar;
Switch swMusica;
MediaPlayer mpSS, mpRoleta;
AnimationDrawable adCaca1, adCaca2, adCaca3;
int iAcumulado, iSaldo,iPartidas, iPremio, iAposta;
    int iImagemSort1, iImagemSort2,iImagemSort3;
    int iImgs [] = {R.drawable.caixa, R.drawable.estrela, R.drawable.jet, R.drawable.ima, R.drawable.bota};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvAcumulado = findViewById(R.id.tvAcumulado);
        tvAposta = findViewById(R.id.tvAposta);
        tvSaldo = findViewById(R.id.tvSaldo);
        tvPartidas = findViewById(R.id.tvPartidas);
        tvPremio = findViewById(R.id.tvPremio);
        iv1 = findViewById(R.id.iv1);
        iv2 = findViewById(R.id.iv2);
        iv3 = findViewById(R.id.iv3);
        btnMais = findViewById(R.id.btnMaisAposta);
        btnMenos = findViewById(R.id.btnMenosAposta);
        btnGirar = findViewById(R.id.btnGirar);
        btnCredito = findViewById(R.id.btnCredito);
        swMusica = findViewById(R.id.swMusica);
        mpSS = MediaPlayer.create(this,R.raw.ss);
        //habilitando a musica em loop
        mpSS.setLooping(true);
        //volume
        mpSS.setVolume(1.0f,1.0f);
        mpRoleta = MediaPlayer.create(this,R.raw.roleta);
        //volume
        mpRoleta.setVolume(1.0f,1.0f);
        mpSS.start();
        iv1.setImageResource(0);
        iv2.setImageResource(0);
        iv3.setImageResource(0);
        iv1.setBackgroundResource(R.drawable.roleta);
        adCaca1 = (AnimationDrawable) iv1.getBackground();
        iv2.setBackgroundResource(R.drawable.roleta);
        adCaca2 = (AnimationDrawable) iv2.getBackground();
        iv3.setBackgroundResource(R.drawable.roleta);
        adCaca3= (AnimationDrawable) iv3.getBackground();

    }
    public void desligar(View l) {
        if (swMusica.isChecked()) {
            mpSS.start();
        } else {
            mpSS.pause();
        }
    }
    public void girar(View g){
        iImagemSort1 = (int) (Math.random()*5);
        iImagemSort2 = (int) (Math.random()*5);
        iImagemSort3 = (int) (Math.random()*5);
        adCaca1.start();
        adCaca2.start();
        adCaca3.start();
        mpRoleta.start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    Thread.sleep(2000);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adCaca1.stop(); //Para animação
                            iv1.setBackgroundResource(iImgs[iImagemSort1]); //Muda a imagem
                        }
                    });
                } catch (Exception e){
                    System.out.println("ERRO: "+ e);
                }
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    Thread.sleep(3000);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adCaca2.stop(); //Para animação
                            iv2.setBackgroundResource(iImgs[iImagemSort2]); //Muda a imagem
                        }
                    });
                } catch (Exception e){
                    System.out.println("ERRO: "+ e);
                }
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    Thread.sleep(4000);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adCaca3.stop(); //Para animação
                            iv3.setBackgroundResource(iImgs[iImagemSort3]); //Muda a imagem
                            mpRoleta.pause(); // pausa o som
                        }
                    });
                } catch (Exception e){
                    System.out.println("ERRO: "+ e);
                }
            }
        }).start();
    }
}