package sp.senai.br.cacaniquel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Handler hdl = new Handler();
        hdl.postDelayed(new Runnable() {
            @Override
            public void run() { carrega();}
            }, 2000);
        }
        public void carrega(){
            Intent it= new Intent(Splash.this, MainActivity.class);
            startActivity(it);
    }
}